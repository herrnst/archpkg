/*
Copyright (C) 1996-2001 Id Software, Inc.
Copyright (C) 2002-2005 John Fitzgibbons and others
Copyright (C) 2007-2008 Kristian Duske
Copyright (C) 2010-2014 QuakeSpasm developers

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "quakedef.h"
#ifndef USE_SDL3
#if defined(SDL_FRAMEWORK) || defined(NO_SDL_CONFIG)
#include <SDL2/SDL_syswm.h>
#else
#include "SDL_syswm.h"
#endif
#endif

static const Uint8 bmp_bytes[] = {
#include "qs_bmp.h"
};

void PL_SetWindowIcon (void)
{
#ifdef USE_SDL3
	SDL_IOStream *rwop;
#else
	SDL_RWops *rwop;
#endif
	SDL_Surface *icon;
	Uint32		 colorkey;

	/* SDL_IOFromConstMem() requires SDL >= 1.2.7 */
#ifdef USE_SDL3
	rwop = SDL_IOFromConstMem (bmp_bytes, sizeof (bmp_bytes));
	if (rwop == NULL)
		return;
	icon = SDL_LoadBMP_IO (rwop, true);
	if (icon == NULL)
		return;
	/* make pure magenta (#ff00ff) tranparent */
	colorkey = SDL_MapSurfaceRGBA (icon, 255, 0, 255, 255);
	SDL_SetSurfaceColorKey (icon, true, colorkey);
	SDL_SetWindowIcon ((SDL_Window *)VID_GetWindow (), icon);
	SDL_DestroySurface (icon);
#else
	rwop = SDL_RWFromConstMem (bmp_bytes, sizeof (bmp_bytes));
	if (rwop == NULL)
		return;
	icon = SDL_LoadBMP_RW (rwop, 1);
	if (icon == NULL)
		return;
	/* make pure magenta (#ff00ff) tranparent */
	colorkey = SDL_MapRGB (icon->format, 255, 0, 255);
	SDL_SetColorKey (icon, SDL_TRUE, colorkey);
	SDL_SetWindowIcon ((SDL_Window *)VID_GetWindow (), icon);
	SDL_FreeSurface (icon);
#endif
}

void PL_VID_Shutdown (void) {}

#define MAX_CLIPBOARDTXT MAXCMDLINE /* 256 */
char *PL_GetClipboardData (void)
{
	char *data = NULL;
	char *cliptext = SDL_GetClipboardText ();

	if (cliptext != NULL)
	{
		size_t size = strlen (cliptext) + 1;
		/* this is intended for simple small text copies
		 * such as an ip address, etc:  do chop the size
		 * here, otherwise we may experience Mem_Alloc()
		 * failures and all other not-oh-so-fun stuff. */
		size = q_min (MAX_CLIPBOARDTXT, size);
		data = (char *)Mem_Alloc (size);
		q_strlcpy (data, cliptext, size);
	}

	return data;
}

void PL_ErrorDialog (const char *errorMsg)
{
	SDL_ShowSimpleMessageBox (SDL_MESSAGEBOX_ERROR, "Quake Error", errorMsg, NULL);
}
